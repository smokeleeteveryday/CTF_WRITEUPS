<?php

namespace hitb\storefront\controllers;

use hitb\core\model\Users;
use hitb\core\security\InvalidCredentialsException;

use hitb\storefront\forms\LoginForm;

/**
 * Provides very safe login functionality ;-)
 */
class LoginController extends AbstractController
{
	/**
	 * Define this controller as publicly accessible.
	 *
	 */
	protected function isPublic() {
		return true;
	}

	/**
	 * Handles the login request.
	 */
    public function indexAction()
    {
		$form = new LoginForm();

		// See if we need to handle the login
		if ($this->request->isPost()) {

			$form->setUid($this->request->getPost("uid"));
			$form->setPwd($this->request->getPost("pwd"));

			if ($form->isValid($_POST)) {
				return $this->handleLogin($form);
			}
		}

		// Show login form
		return $this->showLoginForm($form);
    }

	/**
	 * Show the login form
	 *
	 * @return
	 */
	protected function showLoginForm($form) {
        $this->view->form = $form;
	}

	/**
	 * Login the user and handle any failures.
	 *
	 * @param $uid
	 * @param $pwd
	 * @return 
	 */
	protected function handleLogin($form) {
		try {
			$this->getUserFacade()->login($form->getUid(), $form->getPwd());
			echo "Login success!";

			// redirect to index
			$this->redirect("/");
		} catch (InvalidCredentialsException $e) {
			$form->addValidationConstraint('uid', 'invalid', $e->getMessage());

			// render login template with error msg
        	return $this->showLoginForm($form);
		}
	}

}

