<?php

namespace hitb\core\user;

use hitb\core\model\User;

/**
 * File-based implementation of {@link UserRepository}.
 */
class FileUserRepository implements UserRepository {

	public function getUsers() {

		$users = array();
		$content = $this->readUserFile();
		$lines = explode("\n", $content);
		foreach ($lines as $line) {
			$parts = explode(":", $line);
			if (count($parts) == 5) {
				$user = new User();
				$user->setUid($parts[0]);
				$user->setPwd($parts[1]);
				$user->setName($parts[2]);
				$user->setClearanceLevel($parts[3]);
				$user->setEnabled($parts[4] == "true");
				$users[] = $user;
			}
		}

		return $users;
	}

	protected function readUserFile() {
		$buf = '';
		$fp = fopen("/etc/scc.passwd", "r");
		while (!feof($fp)) {
			$buf .= fgets($fp);
		}
		fclose($fp);

		return $buf;
	}

}

