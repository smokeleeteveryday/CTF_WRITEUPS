<?php

namespace hitb\storefront\controllers;

use Phalcon\Mvc\View;

/**
 * Provides controlled access to static resources
 */
class MediaController extends AbstractController
{
	/**
	 * Define this controller as publicly accessible.
	 *
	 */
	protected function isPublic() {
		return true;
	}

	/**
	 * Handle static resource requests.
	 */
	public function viewAction($file)
	{
		$folder = isset($_GET['folder']) ? $_GET['folder'] . "/" : "../app/storefront/resources/";

		try {
			$fp = $this->getResourceService()->getResourceHandle($folder . $file);
			$this->view->setRenderLevel(View::LEVEL_NO_RENDER);
			$this->response->setHeader("Content-Type", "image/png");
			
			fpassthru($fp);

		} catch (\Exception $e) {
			echo $e->getMessage();
		}
	}

	public function getResourceService() {
		return $this->di->get('resourceService');
	}

}

