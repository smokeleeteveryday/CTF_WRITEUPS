<?php

namespace hitb\facades\user;

/**
 * Interface that provides access to users.
 */
interface UserFacade {

	/**
	 * Retrieves the currently logged in user, if any.
	 *
	 * @return 
	 */
	function getCurrentUser();

	/**
	 * Checks the given credentials and creates a session for the user.
	 *
	 * @throws InvalidCredentialsException
	 * @return 
	 */
	function login($uid, $pwd);

	/**
	 * Removes the session for the current user.
	 *
	 */
	function logout();

}

