<?php

namespace hitb\facades\transponder\data;

/**
 * DTO for a transponder
 *
 */
class TransponderData {

	private $id;
	private $sic;
	private $location;
	private $clearanceLevel;
	private $active;
	private $linkSpeed;
	private $lastStatus;
	private $totalPacketsRecv;
	private $dateAdded;
	private $dateLastStatus;
	private $dateLastTransmission;

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getSic(){
		return $this->sic;
	}

	public function setSic($sic){
		$this->sic = $sic;
	}

	public function getLocation(){
		return $this->location;
	}

	public function setLocation($location){
		$this->location = $location;
	}

	public function getClearanceLevel(){
		return $this->clearanceLevel;
	}

	public function setClearanceLevel($clearanceLevel){
		$this->clearanceLevel = $clearanceLevel;
	}

	public function getActive(){
		return $this->active;
	}

	public function setActive($active){
		$this->active = $active;
	}

	public function getLinkSpeed(){
		return $this->linkSpeed;
	}

	public function setLinkSpeed($linkSpeed){
		$this->linkSpeed = $linkSpeed;
	}

	public function getLastStatus(){
		return $this->lastStatus;
	}

	public function setLastStatus($lastStatus){
		$this->lastStatus = $lastStatus;
	}

	public function getTotalPacketsRecv(){
		return $this->totalPacketsRecv;
	}

	public function setTotalPacketsRecv($totalPacketsRecv){
		$this->totalPacketsRecv = $totalPacketsRecv;
	}

	public function getDateAdded(){
		return $this->dateAdded;
	}

	public function setDateAdded($dateAdded){
		$this->dateAdded = $dateAdded;
	}

	public function getDateLastStatus(){
		return $this->dateLastStatus;
	}

	public function setDateLastStatus($dateLastStatus){
		$this->dateLastStatus = $dateLastStatus;
	}

	public function getDateLastTransmission(){
		return $this->dateLastTransmission;
	}

	public function setDateLastTransmission($dateLastTransmission){
		$this->dateLastTransmission = $dateLastTransmission;
	}

}

