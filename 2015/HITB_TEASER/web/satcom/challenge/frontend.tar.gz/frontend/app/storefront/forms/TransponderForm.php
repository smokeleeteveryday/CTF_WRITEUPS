<?php

namespace hitb\storefront\forms;

use hitb\util\forms\Form;

/**
 * Transponder form.
 */
class TransponderForm extends Form {

	private $sic;
	private $location;
	private $cl;

	public function getSic() {
		return $this->sic;
	}

	public function setSic($sic) {
		if (empty($sic)) {
			$this->addValidationConstraint('sic', 'empty', 'sic is required');
		}

		$this->sic = $sic;
	}

	public function getLocation() {
		return $this->location;
	}

	public function setLocation($location) {
		if (empty($location)) {
			$this->addValidationConstraint('location', 'empty', 'location is required');
		}

		$this->location = $location;
	}

	public function getCl() {
		return $this->cl;
	}

	public function setCl($cl) {
		if (empty($cl)) {
			$this->addValidationConstraint('cl', 'empty', 'cl is required');
		}

		$this->cl = $cl;
	}
}

