<?php

namespace hitb\storefront\forms;

use hitb\util\forms\Form;

/**
 * Login form.
 */
class LoginForm extends Form {

	private $uid;
	private $pwd;

	public function getUid() {
		return $this->uid;
	}

	public function setUid($uid) {
		if (empty($uid)) {
			$this->addValidationConstraint('uid', 'empty', 'Uid is required');
		}

		$this->uid = $uid;
	}

	public function getPwd() {
		return $this->pwd;
	}

	public function setPwd($pwd) {
		if (empty($pwd)) {
			$this->addValidationConstraint('pwd', 'empty', 'Pwd is required');
		}

		$this->pwd = $pwd;
	}
}

