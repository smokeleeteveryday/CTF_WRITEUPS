<?php

namespace hitb\facades\activity\data;

/**
 * DTO for an activity
 *
 */
class ActivityData {

	private $title;
	private $text;

	public function getTitle() {
		return $this->title;
	}

	public function setTitle($title) {
		$this->title = $title;
	}

	public function getText() {
		return $this->text;
	}

	public function setText($text) {
		$this->text = $text;
	}

}

