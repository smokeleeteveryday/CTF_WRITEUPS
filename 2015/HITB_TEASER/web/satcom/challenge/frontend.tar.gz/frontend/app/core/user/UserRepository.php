<?php

namespace hitb\core\user;

/**
 * Interface for a repository that provides access to users.
 */
interface UserRepository {

	/**
	 * Retrieves a list of users from the underlying datasource.
	 */
	function getUsers();

}

