<?php

namespace hitb\facades\user;

use hitb\core\security\AuthenticationService;
use hitb\core\session\SessionService;
use hitb\util\converter\Converter;

use Phalcon\Session\AdapterInterface;

/**
 * Default implementation of {@link UserFacade}.
 */
class DefaultUserFacade implements UserFacade {

	const SID = "user";

	private $authenticationService;
	private $sessionService;
	private $userConverter;

	/**
	 * Retrieves the currently logged in user, if any.
	 *
	 * @return the current user data, or null if not logged in
	 */
	public function getCurrentUser() {

		if (!$this->getSessionService()->has(self::SID)) {
			return null;
		}

		return $this->getSessionService()->get(self::SID);
	}

	/**
	 * Checks the given credentials and creates a session for the user.
	 *
	 * @throws InvalidCredentialsException if an error occurs
	 * @return the user data
	 */
	public function login($uid, $pwd) {

		$user = $this->getAuthenticationService()->verifyCredentials($uid, $pwd);

		$userData = $this->getUserConverter()->convert($user);

		$this->getSessionService()->set(self::SID, $userData);

		return $userData;
	}

	/**
	 * Removes the session for the current user.
	 *
	 */
	public function logout() {
		$this->getSessionService()->remove(self::SID);
	}

	public function getAuthenticationService() {
		return $this->authenticationService;
	}

	public function setAuthenticationService(AuthenticationService $authenticationService) {
		$this->authenticationService = $authenticationService;
	}

	public function getSessionService() {
		return $this->sessionService;
	}

	public function setSessionService(AdapterInterface $sessionService) {
		$this->sessionService = $sessionService;
	}

	public function getUserConverter() {
		return $this->userConverter;
	}

	public function setUserConverter(Converter $userConverter) {
		$this->userConverter = $userConverter;
	}

}

