<?php

namespace hitb\core\security;

use hitb\core\user\UserRepository;

/**
 * Provides a file-based user authentication mechanism.
 *
 */
class DefaultAuthenticationService implements AuthenticationService {

	private $userRepository;

	/**
	 * Verifies the given credentials
	 *
	 * @param $uid the user id
	 * @param $pwd the password
	 * @throws InvalidCredentialsException
	 * @return user instance
	 */
	public function verifyCredentials($uid, $pwd) {

		// Get users
		$users = $this->getUserRepository()->getUsers();

		foreach ($users as $user) {
			if ($user->getUid() == $uid && $user->getPwd() == $pwd) {
				if (!$user->getEnabled()) {
					throw new InvalidCredentialsException("user is disabled");
				}

				return $user;
			}
		}

		throw new InvalidCredentialsException("uid or pwd invalid");
	}

	public function getUserRepository() {
		return $this->userRepository;
	}

	public function setUserRepository(UserRepository $userRepository) {
		$this->userRepository = $userRepository;
	}

}
