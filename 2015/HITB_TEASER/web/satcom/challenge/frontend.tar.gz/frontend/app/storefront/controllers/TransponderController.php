<?php

namespace hitb\storefront\controllers;

use hitb\facades\transponder\data\TransponderData;
use hitb\storefront\forms\ActivationForm;
use hitb\storefront\forms\TransponderForm;

/**
 * Controller for product specific functionality.
 *
 */
class TransponderController extends AbstractController {

	/**
	 * Lists all the important transponders.
	 *
	 */
	public function listAction() {
		$transponders = $this->getTransponderFacade()->getImportantTransponders();

		$this->view->transponders = $transponders;
	}

	/**
	 * Displays the transponder for the given id.
	 *
	 * @param $transponderId the transponders identifier
	 */
    public function viewAction($transponderId) {
        $transponder = $this->getTransponderFacade()->getTransponderById($transponderId);

		$this->view->transponder = $transponder;
    }

	/**
	 * Shows the current status for the given transponder.
	 *
	 * @param $transponderId the transponders identifier
	 */
    public function statusAction($transponderId) {
		$status = $this->getTransponderFacade()->requestStatusForTransponder($transponderId);
        $transponder = $this->getTransponderFacade()->getTransponderById($transponderId);

		$this->view->transponder = $transponder;
		$this->view->status = "Update successful";

		$this->view->pick("transponder/view");
    }

	/**
	 * Shows the packet data for the given transponder.
	 *
	 * @param $transponderId the transponders identifier
	 */
    public function packetAction($transponderId) {
		try {
			$transponder = $this->getTransponderFacade()->getTransponderById($transponderId);
			$packetData = $this->getTransponderFacade()->viewPacketDataForTransponder($transponder);

			$this->view->transponder = $transponder;
			$this->view->packetData = $packetData;
		}
		catch (\Exception $e) {
			$this->view->status = $e->getMessage();
		}
    }

	/**
	 * Add a transponder.
	 *
	 * @param $transponderId the transponders identifier
	 */
    public function addAction() {
		$form = new TransponderForm();

		// See if we need to handle the login
		if ($this->request->isPost()) {

			$form->setSic($this->request->getPost("sic"));
			$form->setLocation($this->request->getPost("location"));
			$form->setCl($this->getUserFacade()->getCurrentUser()->getClearanceLevel());

			if ($form->isValid()) {
				return $this->addTransponder($form);
			}
		}

		// Show login form
		return $this->showForm($form);
    }

	/**
	 * Show the login form
	 *
	 * @return
	 */
	protected function showForm($form) {
        $this->view->form = $form;
	}

	/**
	 * Adds a transponder.
	 *
	 * @param @form
	 */
	protected function addTransponder($form) {
		try {
			// Convert form to data using the binder
			$data = new TransponderData();
			$data->setSic($form->getSic());
			$data->setLocation($form->getLocation());
			$data->setClearanceLevel($form->getCl());

			// Add the transponder
			$result = $this->getTransponderFacade()->addTransponder($data);

			$this->redirect("/transponder/view/" . $result->getId());
		} catch (\Exception $exception) {
			$form->addValidationConstraint('sic', 'invalid', $exception->getMessage());
			return $this->showForm($form);
		}
    }

	/**
	 * Activate a transponder.
	 *
	 * @param $transponderId the transponders identifier
	 */
    public function activateAction() {
		$form = new ActivationForm();

		// See if we need to handle the login
		if ($this->request->isPost()) {

			$form->setSic($this->request->getPost("sic"));

			if ($form->isValid()) {
				return $this->activateTransponder($form);
			}
		}

		// Show login form
		return $this->showForm($form);
    }

	/**
	 * Activates a transponder.
	 *
	 * @param @form
	 */
	protected function activateTransponder($form) {
		try {
			// Convert form to data using the binder
			$data = new TransponderData();
			$data->setSic($form->getSic());

			// Activate the transponder
			$result = $this->getTransponderFacade()->activateTransponder($data);

			$form->addValidationConstraint('sic', 'complete', 'Transponder "' . $result->getSic() . '" activated');

		} catch (\Exception $exception) {
			$form->addValidationConstraint('sic', 'invalid', $exception->getMessage());
		}

		return $this->showForm($form);
    }

	protected function getTransponderFacade() {
		return $this->di->get('transponderFacade');
	}

}

