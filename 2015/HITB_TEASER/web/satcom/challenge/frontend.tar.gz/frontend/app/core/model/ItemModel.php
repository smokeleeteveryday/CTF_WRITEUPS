<?php

namespace hitb\core\model;

/**
 * A generic contract that represents a single instance of an object.
 */ 
interface ItemModel {

	/**
	 * Returns a unique identifier for the current instance of the object.
	 */
	function getId();

}

