<?php

namespace hitb\facades\transponder;

use hitb\core\model\Transponder;
use hitb\core\transponder\TransponderService;

use hitb\external\service\TransponderControlServiceClient;

use hitb\facades\user\UserFacade;

use hitb\util\converter\Converter;
use hitb\util\converter\Converters;

/**
 * Default implementation of {@link TransponderFacade}.
 */
class DefaultTransponderFacade implements TransponderFacade {

	private $userFacade;
	private $transponderService;
	private $transponderConverter;
	private $transponderControlServiceClient;

	public function getImportantTransponders() {

		$transponders = $this->getTransponderService()->getTransponders();

		return Converters::convertAll($transponders, $this->getTransponderConverter());
	}

	public function getTransponderById($transponderId) {

		$transponder = $this->getTransponderService()->getTransponderById($transponderId);

		return $this->getTransponderConverter()->convert($transponder);
	}

	public function requestStatusForTransponder($transponderId) {
		$user = $this->getUserFacade()->getCurrentUser();
		$this->getTransponderControlServiceClient()->createSession($user->getUid());

		$status = $this->getTransponderControlServiceClient()->getStatus($transponderId);

		$transponder = $this->getTransponderService()->getTransponderById($transponderId);
		$transponder->setTotalPacketsRecv($transponder->getTotalPacketsRecv() + $status->packetsReceived);
		$transponder->setLinkSpeed($status->linkSpeed);
		$transponder->setDateLastTransmission($status->dateLastTransmission);
		$transponder->setLastStatus($status->status);
		$transponder->setDateLastStatus(date('Y-m-d H:i:s'));

		$result = $this->getTransponderService()->save($transponder);

		return $this->getTransponderConverter()->convert($result);
	}

	public function viewPacketDataForTransponder($transponder) {
		$user = $this->getUserFacade()->getCurrentUser();
		$this->getTransponderControlServiceClient()->createSession($user->getUid());

		$result = $this->getTransponderControlServiceClient()->getPacketData($transponder->getSic());

		return nl2br($result);
	}

	public function activateTransponder($transponder) {

		$record = $this->getTransponderService()->getTransponderBySic($transponder->getSic());
		if ($record->getActive()) {
			throw new \Exception('Transponder "' . $record->getSic() . '" already activated');
		}

		$record->setActive(1);
		$result = $this->getTransponderService()->save($record);

		return $this->getTransponderConverter()->convert($result);
	}

	public function addTransponder($transponder) {
		$record = new Transponder();
		$record->setSic($transponder->getSic());
		$record->setLocation($transponder->getLocation());
		$record->setClearanceLevel($transponder->getClearanceLevel());
		$record->setActive(0);
		$record->setDateAdded(date('Y-m-d H:i:s'));

		$result = $this->getTransponderService()->save($record);

		return $this->getTransponderConverter()->convert($result);
	}

	public function getTransponderService() {
		return $this->transponderService;
	}

	public function setTransponderService(TransponderService $transponderService) {
		$this->transponderService = $transponderService;
	}

	public function getTransponderConverter() {
		return $this->transponderConverter;
	}

	public function setTransponderConverter(Converter $transponderConverter) {
		$this->transponderConverter = $transponderConverter;
	}

	public function getTransponderControlServiceClient() {
		return $this->transponderControlServiceClient;
	}

	public function setTransponderControlServiceClient(TransponderControlServiceClient $transponderControlServiceClient) {
		$this->transponderControlServiceClient = $transponderControlServiceClient;
	}

	public function getUserFacade() {
		return $this->userFacade;
	}

	public function setUserFacade(UserFacade $userFacade) {
		$this->userFacade = $userFacade;
	}

}

