<?php

namespace hitb\facades\activity\converter;

use hitb\core\model\Activity;

use hitb\facades\activity\data\ActivityData;

use hitb\util\converter\AbstractConverter;

/**
 * Converter for activities.
 */
class ActivityConverter extends AbstractConverter {

	/**
	 * Converts the given Activity to a ActivityData object.
	 *
	 * @param $source
	 * @param $target
	 * @return
	 */
	public function convertExisting($source, $target) {

		$target->setTitle($source->getTitle());
		$target->setText($source->getText());

		return $target;
	}

	public function createTarget() {
		return new ActivityData();
	}

}

