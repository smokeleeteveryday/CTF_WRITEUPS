<?php

namespace hitb\core\transponder;

/**
 *
 */
interface TransponderService {

	/**
	 * Fetches an transponder by id
	 *
	 * @param $transponderId the transponder identifier
	 * @throws ModelNotFoundException
	 * @return 
	 */
	function getTransponderById($transponderId);

	/**
	 * Fetches an transponder by sic
	 *
	 * @param $transponderId the subscriber identity code
	 * @throws ModelNotFoundException
	 * @return 
	 */
	function getTransponderBySic($sic);

	/**
	 * Fetches the transponders
	 *
	 */
	function getTransponders();

	/**
	 * Saves the given transponder
	 *
	 * @throws Exception
	 * @return the saved model
	 */
	function save($transponder);

}

