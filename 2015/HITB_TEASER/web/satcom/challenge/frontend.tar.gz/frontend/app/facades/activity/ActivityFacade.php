<?php

namespace hitb\facades\activity;

/**
 * Interface for a facade that provides access to activities.
 */
interface ActivityFacade {

	/**
	 * Retrieves the available activites, if any.
	 *
	 * @return a list of activities
	 */
	function getLatestActivities();

}
