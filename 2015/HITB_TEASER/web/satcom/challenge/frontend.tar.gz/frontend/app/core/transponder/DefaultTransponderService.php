<?php

namespace hitb\core\transponder;

use hitb\core\model\Transponder;
use hitb\core\ModelNotFoundException;

use Phalcon\Mvc\Model\Resultset\Simple as Resultset;

/**
 * Default implementation of {@link TransponderService}.
 */
class DefaultTransponderService implements TransponderService {

	public function getTransponderById($transponderId) {
		
		$transponder = Transponder::findFirstById($transponderId);

		if ($transponder == null) {
			throw new ModelNotFoundException("could not find transponder with id " . $transponderId);
		}

		return $transponder;
	}

	public function getTransponderBySic($sic) {

		$sql = "SELECT * FROM transponder WHERE sic = '" . $sic . "'";
		$transponder = new Transponder();
		$list = new Resultset(null, $transponder, $transponder->getReadConnection()->query($sql, null));

		if ($list == null || count($list) == 0) {
			throw new ModelNotFoundException("could not find transponder with sic " . $sic);
		}

		return $list[0];
	}

	public function getTransponders() {

		$transponders = Transponder::find(array(
			"order" => "clearanceLevel DESC, id DESC",
			"limit" => 20
		));

		return $transponders;
	}

	public function save($transponder) {
		if ($transponder->save() == false) {
			$msgs = $transponder->getMessages();
			throw new \Exception($msgs[0]);
		}

		return $transponder;
	}

}

