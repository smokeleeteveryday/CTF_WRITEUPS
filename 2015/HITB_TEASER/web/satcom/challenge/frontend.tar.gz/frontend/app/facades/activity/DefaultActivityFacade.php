<?php

namespace hitb\facades\activity;

use hitb\core\activity\ActivityService;

use hitb\util\converter\Converter;
use hitb\util\converter\Converters;

/**
 * Default implementation of {@link ActivityFacade}.
 */
class DefaultActivityFacade implements ActivityFacade {

	private $activityService;
	private $activityConverter;

	/**
	 * Retrieves the latest activities.
	 *
	 * @return an array of {@link ActivityData} elements, or null if none are found
	 */
	public function getLatestActivities() {

		$activities = $this->getActivityService()->getLatestActivities();

		return Converters::convertAll($activities, $this->getActivityConverter());
	}

	public function getActivityService() {
		return $this->activityService;
	}

	public function setActivityService(ActivityService $activityService) {
		$this->activityService = $activityService;
	}

	public function getActivityConverter() {
		return $this->activityConverter;
	}

	public function setActivityConverter(Converter $activityConverter) {
		$this->activityConverter = $activityConverter;
	}

}

