<?php

namespace hitb\storefront\controllers;

use Phalcon\Mvc\Dispatcher;
use Phalcon\Mvc\View;

/**
 * Base controller for all controllers. 
 *
 * This class extends from the Phalcon Controller and
 * provides common functionality that can be used in 
 * all child controllers.
 */
abstract class AbstractController extends \Phalcon\Mvc\Controller {

	/**
	 * Provides authorization if required.
	 *
	 * @param $dispatcher
	 */
	public function beforeExecuteRoute(Dispatcher $dispatcher) {
		if (!$this->isPublic()) {
			$user = $this->getUserFacade()->getCurrentUser();
			if ($user == null) {
				$this->redirect("/login");
			}
		}
	}

	/**
	 * Adds additional elements to every view.
	 *
	 * @param $dispatcher
	 */
	public function afterExecuteRoute(Dispatcher $dispatcher) {
		$user = $this->getUserFacade()->getCurrentUser();
		$this->view->user = $user;
	}

	/**
	 * Defines the accessibility state for the controller.
	 *
	 * The default state is private, and this can be overridden in
	 * the concrete controllers.
	 *
	 */
	protected function isPublic() {
		return false;
	}

	/**
	 * Redirects the user to the given page.
	 *
	 * @param $url
	 * @param $level
	 */
	protected function redirect($url, $level = 302) {
		$this->view->setRenderLevel(View::LEVEL_NO_RENDER);
		$this->response->redirect($url, true, $level);
	}

	/**
	 * Retrieves the user facade.
	 *
	 */
	protected function getUserFacade() {
		return $this->di->get('userFacade');
	}

}
