<?php

namespace hitb\storefront\controllers;

use hitb\core\model\Activity;

use hitb\facades\activity\ActivityFacade;

/**
 * Handles the index page.
 */
class IndexController extends AbstractController
{
	/**
	 * Shows the index page.
	 */
    public function indexAction()
    {
		$activities = $this->getActivityFacade()->getLatestActivities();

		$this->view->activities = $activities;
    }

	protected function getActivityFacade() {
		return $this->di->get('activityFacade');
	}

}

