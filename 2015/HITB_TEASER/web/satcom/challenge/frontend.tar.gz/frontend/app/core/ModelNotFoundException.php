<?php

namespace hitb\core;

/**
 * Represents an exception that can be thrown
 * when a model is not found in the underlying
 * datasource.
 */
class ModelNotFoundException extends \Exception {

	/**
	 * Default constructor
	 */
	public function __construct($message) {
		parent::__construct($message);
	}

}
