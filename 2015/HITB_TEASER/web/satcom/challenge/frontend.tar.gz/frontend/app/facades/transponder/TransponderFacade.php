<?php

namespace hitb\facades\transponder;

/**
 * Interface that provides access to transponders.
 */
interface TransponderFacade {

	/**
	 * Retrieves all import transponders, if any.
	 */
	function getImportantTransponders();

	/**
	 * Retrieves a transponder by id.
	 */
	function getTransponderById($transponderId);

	/**
	 * Requests the current status for the given transponder.
	 */
	function requestStatusForTransponder($transponderId);

	/**
	 * Retrieves the packet data for the given transponder.
	 */
	function viewPacketDataForTransponder($transponderId);

	/**
	 * Activates the given transponder.
	 */
	function activateTransponder($transponder);

	/**
	 * Adds the given transponder
	 */
	function addTransponder($transponder);

}

