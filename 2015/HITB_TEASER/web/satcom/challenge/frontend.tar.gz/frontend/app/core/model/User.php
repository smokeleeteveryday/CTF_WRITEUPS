<?php

namespace hitb\core\model;

/**
 * Represents a single instance of a user.
 */ 
class User implements ItemModel {

	protected $uid;
	protected $pwd;
	protected $name;
	protected $clearanceLevel;
	protected $enabled;

	public function getId() {
		return $this->getUid();
	}

	public function getUid() {
		return $this->uid;
	}

	public function setUid($uid) {
		$this->uid = $uid;
	}

	public function getPwd() {
		return $this->pwd;
	}

	public function setPwd($pwd) {
		$this->pwd = $pwd;
	}

	public function getName() {
		return $this->name;
	}

	public function setName($name) {
		$this->name = $name;
	}

	public function getClearanceLevel() {
		return $this->clearanceLevel;
	}

	public function setClearanceLevel($clearanceLevel) {
		$this->clearanceLevel = $clearanceLevel;
	}

	public function getEnabled() {
		return $this->enabled;
	}

	public function setEnabled($enabled) {
		$this->enabled = $enabled;
	}
}

