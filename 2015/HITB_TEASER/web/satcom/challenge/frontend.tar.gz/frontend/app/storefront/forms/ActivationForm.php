<?php

namespace hitb\storefront\forms;

use hitb\util\forms\Form;

/**
 * Activation form.
 */
class ActivationForm extends Form {

	private $sic;

	public function getSic() {
		return $this->sic;
	}

	public function setSic($sic) {
		if (empty($sic)) {
			$this->addValidationConstraint('sic', 'empty', 'sic is required');
		}

		$this->sic = $sic;
	}

}

