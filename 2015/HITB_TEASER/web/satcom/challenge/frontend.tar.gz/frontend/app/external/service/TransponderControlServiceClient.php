<?php

namespace hitb\external\service;

/**
 * Provides a client interface for the transponder control webservice.
 */
class TransponderControlServiceClient {

	private $client;
	private $configurationService;

	protected function init($uid) {
		if ($this->client != null) {
			return;
		}
		$endpoint = $this->getEndpoint();
		$this->client = new \SoapClient($this->getEndpoint(),
			array(
				'soap_version' => SOAP_1_2
			)
		);
		$this->client->createSessionForUid($this->getSecret(), $uid);
	}

	public function getStatus($sic) {

		if (!$this->hasSession()) {
			throw new \SoapFault('server', 'session is required');
		}

		return $this->client->getStatus($sic);
	}

	public function getPacketData($sic) {

		if (!$this->hasSession()) {
			throw new \SoapFault('server', 'session is required');
		}

		return $this->client->getPacketData($sic);
	}

	protected function hasSession() {
		return $this->client != null;
	}

	public function createSession($uid) {
		$this->init($uid);
	}

	protected function getSecret() {
		return $this->getConfigurationService()->get('external.webservice.secret')->getValue();
	}

	protected function getEndpoint() {
		return $this->getConfigurationService()->get('external.webservice.endpoint')->getValue();
	}

	public function getConfigurationService() {
		return $this->configurationService;
	}

	public function setConfigurationService($configurationService) {
		$this->configurationService = $configurationService;
	}

}

