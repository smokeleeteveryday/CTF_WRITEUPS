<?php

namespace hitb\core\configuration;

use hitb\core\model\Config;
use hitb\core\ModelNotFoundException;

/**
 * Default implementation of {@link ConfigurationService}.
 */
class DefaultConfigurationService implements ConfigurationService {

	public function get($key) {
		
		$value = Config::findFirstByKey($key);

		if ($value == null) {
			throw new ModelNotFoundException("could not find config value with key " . $key);
		}

		return $value;
	}

}

