<?php

use hitb\core\activity\DefaultActivityService;
use hitb\core\configuration\DefaultConfigurationService;
use hitb\core\location\DefaultLocationService;
use hitb\core\resource\DefaultResourceService;
use hitb\core\transponder\DefaultTransponderService;
use hitb\core\security\DefaultAuthenticationService;
use hitb\core\user\FileUserRepository;

use hitb\external\service\TransponderControlServiceClient;

use hitb\facades\activity\converter\ActivityConverter;
use hitb\facades\activity\DefaultActivityFacade;
use hitb\facades\transponder\converter\TransponderConverter;
use hitb\facades\transponder\DefaultTransponderFacade;
use hitb\facades\user\converter\UserConverter;

use Phalcon\Db\Adapter\Pdo\Mysql;
use Phalcon\DI\FactoryDefault;
use Phalcon\Mvc\Dispatcher;
use Phalcon\Mvc\Url;
use Phalcon\Mvc\View;
use Phalcon\Mvc\View\Engine\Volt;
use Phalcon\Session\Adapter\Files;

// Create a DI
$di = new FactoryDefault();

// Sessions
$di->set('sessionService', function() {
	$session = new Files();
	$session->start();

	return $session;
});

// Configuration
$di->set('configurationService', function() {
	return new DefaultConfigurationService();
});

// Resources
$di->set('resourceService', function() {
	return new DefaultResourceService();
});

// External
$di->set('transponderControlServiceClient', function() use ($di) {
	$client = new TransponderControlServiceClient();
	$client->setConfigurationService($di->get('configurationService'));
	return $client;
});

// Users
$di->set('userConverter', function() {
	return new UserConverter();
});

$di->set('userRepository', function() {
	return new FileUserRepository();
});

$di->set('authenticationService', function() use ($di) {
	$auth = new DefaultAuthenticationService();
	$auth->setUserRepository($di->get('userRepository'));
	return $auth;
});

$di->set('userFacade', array(
	"className" => "hitb\\facades\\user\\DefaultUserFacade",
	"calls" => array(
		array(
			"method" => "setAuthenticationService",
			"arguments" => array(
				array('type' => 'service', 'name' => 'authenticationService')
			)
		),
		array(
			"method" => "setSessionService",
			"arguments" => array(
				array('type' => 'service', 'name' => 'sessionService')
			)
		),
		array(
			"method" => "setUserConverter",
			"arguments" => array(
				array('type' => 'service', 'name' => 'userConverter')
			)
		)
	)
));

// Locations
$di->set('locationService', function() {
	return new DefaultLocationService();
});

// Transponders
$di->set('transponderConverter', function() use ($di) {
	$tc = new TransponderConverter();
	$tc->setLocationService($di->get('locationService'));
	return $tc;
});

$di->set('transponderService', function() {
	return new DefaultTransponderService();
});

$di->set('transponderFacade', array(
	"className" => "hitb\\facades\\transponder\\DefaultTransponderFacade",
	"calls" => array(
		array(
			"method" => "setTransponderService",
			"arguments" => array(
				array('type' => 'service', 'name' => 'transponderService')
			)
		),
		array(
			"method" => "setTransponderConverter",
			"arguments" => array(
				array('type' => 'service', 'name' => 'transponderConverter')
			)
		),
		array(
			"method" => "setUserFacade",
			"arguments" => array(
				array('type' => 'service', 'name' => 'userFacade')
			)
		),
		array(
			"method" => "setTransponderControlServiceClient",
			"arguments" => array(
				array('type' => 'service', 'name' => 'transponderControlServiceClient')
			)
		)
	)
));

// Activities
$di->set('activityConverter', function() {
	return new ActivityConverter();
});

$di->set('activityService', function() {
	return new DefaultActivityService();
});

$di->set('activityFacade', array(
	"className" => "hitb\\facades\\activity\\DefaultActivityFacade",
	"calls" => array(
		array(
			"method" => "setActivityService",
			"arguments" => array(
				array('type' => 'service', 'name' => 'activityService')
			)
		),
		array(
			"method" => "setActivityConverter",
			"arguments" => array(
				array('type' => 'service', 'name' => 'activityConverter')
			)
		)
	)
));

// Setup the database service
$di->set('db', function() use ($config) {
	return new Mysql(array(
		"host" => $config->database->host,
		"username" => $config->database->username,
		"password" => $config->database->password,
		"dbname" => $config->database->name
	));
});

// Register Volt view engine
$di->set('voltService', function($view, $di) {
	$volt = new Volt($view, $di);
	$volt->setOptions(array(
		"compiledPath" => "../app/storefront/cache/compiled-templates/",
		"compiledExtension" => ".compiled",
		"compiledSeparator" => "__",
		"compileAlways" => true
	));

	return $volt;
});

// Setup the dispatcher
$di->set('dispatcher', function() {
	$dispatcher = new Dispatcher();
	$dispatcher->setDefaultNamespace('hitb\storefront\controllers\\');

	return $dispatcher;
});

// Setup the view component
$di->set('view', function() {
	$view = new View();
	$view->setViewsDir('../app/storefront/views/');
	$view->registerEngines(array(
		".volt" => "voltService"
	));

	return $view;
});

// Setup a base URI so that all generated URIs include the "tutorial" folder
$di->set('url', function() {
	$url = new Url();
	$url->setBaseUri('/tutorial/');

	return $url;
});

