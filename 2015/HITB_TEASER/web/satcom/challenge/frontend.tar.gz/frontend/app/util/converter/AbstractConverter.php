<?php

namespace hitb\util\converter;

/**
 * Base class for a converter that provides dynamic instance creation
 * for the destination type.
 *
 */
abstract class AbstractConverter implements Converter {

	/**
	 * Abstract method that should be implemented by the child class to create
	 * the desired target object instance.
	 */
	public abstract function createTarget();

	/**
	 * Converts the source object by filling a new instance of the target type.
	 *
	 * @param $source the source object
	 * @return the converted object
	 * @throws ConversionException if a conversion error occurs
	 */
	public function convert($source) {
		$target = $this->createTarget();

		return $this->convertExisting($source, $target);
	}

}

