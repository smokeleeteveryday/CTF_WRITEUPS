<?php

namespace hitb\storefront\controllers;

/**
 * Handles user logout functionality.
 */
class LogoutController extends AbstractController
{
	/**
	 * Logout the current user.
	 */
    public function indexAction()
    {
		$this->getUserFacade()->logout();
		$this->redirect("/login");
    }

}
