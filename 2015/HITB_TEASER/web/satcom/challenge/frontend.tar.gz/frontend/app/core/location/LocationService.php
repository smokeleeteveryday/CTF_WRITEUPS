<?php

namespace hitb\core\location;

/**
 * Interface for a service that can find a location.
 */
interface LocationService {

	/**
	 * Fetches a location by id.
	 *
	 * @param $locationId the location identifier
	 * @throws ModelNotFoundException
	 * @return a location
	 */
	function getLocationById($locationId);

}

