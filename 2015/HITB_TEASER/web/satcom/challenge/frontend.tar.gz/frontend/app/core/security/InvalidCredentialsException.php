<?php

namespace hitb\core\security;

/**
 * Represents an exception that can be thrown
 * when a model is not found in the underlying
 * datasource.
 */
class InvalidCredentialsException extends \Exception {

	/**
	 * Default constructor
	 */
	public function __construct($message) {
		parent::__construct($message);
	}

}
