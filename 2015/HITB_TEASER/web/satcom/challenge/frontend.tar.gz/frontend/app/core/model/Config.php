<?php

namespace hitb\core\model;

/**
 * Represents a single instance of a configuration element.
 */ 
class Config extends \Phalcon\Mvc\Model implements ItemModel {

	protected $id;
	protected $key;
	protected $value;

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getKey(){
		return $this->key;
	}

	public function setKey($key){
		$this->key = $key;
	}

	public function getValue(){
		return $this->value;
	}

	public function setValue($value){
		$this->value = $value;
	}

}
