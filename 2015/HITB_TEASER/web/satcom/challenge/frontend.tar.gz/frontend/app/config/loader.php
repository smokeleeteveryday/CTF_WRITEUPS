<?php

// Register an autoloader
$loader = new \Phalcon\Loader();
$loader->registerNamespaces(
	array(
		'hitb' => "../app/"
	)
)->register();

