<?php

namespace hitb\util\converter;

/**
 * Utility class that provides conversion helper methods.
 *
 */
class Converters {

	/**
	 * Converts an array of source objects using the given converter.
	 *
	 * @param an array of source objects 
	 * @param a {@link Converter} instance
	 * @return a list of converted items
	 */
	public static function convertAll($sourceList, Converter $converter) {

		$result = array();

		if ($sourceList == null) {
			return $result;
		}

		foreach ($sourceList as $source) {
			$result[] = $converter->convert($source);
		}

		return $result;
	}

}

