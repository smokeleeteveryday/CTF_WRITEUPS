<?php

namespace hitb\util\converter;

/**
 * Interface for a converter that transforms an object of one type
 * into an object of another type.
 *
 */
interface Converter {

	/**
	 * Converts the source object by filling the existing target instance.
	 *
	 * @param $source the source object
	 * @param $target the target object
	 * @return the converted object
	 * @throws ConversionException if a conversion error occurs
	 */
	function convertExisting($source, $target);

}

