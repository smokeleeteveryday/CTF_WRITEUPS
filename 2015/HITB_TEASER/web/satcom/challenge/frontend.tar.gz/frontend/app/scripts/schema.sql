DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(70) NOT NULL,
  `text` TEXT NOT NULL,
  PRIMARY KEY (`id`)
);

DROP TABLE IF EXISTS `transponder`;
CREATE TABLE `transponder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sic` varchar(70) NOT NULL,
  `location` varchar(70) NOT NULL,
  `clearanceLevel` int(10),
  `active` int(1) NOT NULL,
  `linkSpeed` varchar(70),
  `lastStatus` varchar(70),
  `totalPacketsRecv` INT(10),
  `dateAdded` DATETIME,
  `dateLastStatus` DATETIME,
  `dateLastTransmission` DATETIME,
  PRIMARY KEY (`id`),
  CONSTRAINT `uc_sic` UNIQUE (`sic`)
);

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(70) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
