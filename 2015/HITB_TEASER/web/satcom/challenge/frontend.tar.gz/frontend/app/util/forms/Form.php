<?php

namespace hitb\util\forms;

abstract class Form {

	protected $constraints = array();

	public function isValid() {
		// TODO
		return count($this->constraints) == 0;
	}

	public function addValidationConstraint($element, $key, $value) {

		// Create entry if required
		if (!array_key_exists($element, $this->constraints)) {
			$this->constraints[$element] = array();
		}

		$constraints =& $this->constraints[$element];
		$constraints[$key] = $value;

	}

	public function getMessages() {
		$messages = array();
		foreach ($this->constraints as $constraint) {
			foreach ($constraint as $c) {
				$messages[] = $c;
			}
		}
		return $messages;
	}

}

