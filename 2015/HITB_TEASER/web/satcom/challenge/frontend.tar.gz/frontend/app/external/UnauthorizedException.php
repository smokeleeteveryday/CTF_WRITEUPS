<?php

namespace hitb\external;

/**
 * Represents an exception that can be thrown
 * when a user is not eligible for the requested
 * action.
 */
class UnauthorizedException extends \Exception {

	/**
	 * Default constructor
	 */
	public function __construct($message) {
		parent::__construct($message);
	}

}

