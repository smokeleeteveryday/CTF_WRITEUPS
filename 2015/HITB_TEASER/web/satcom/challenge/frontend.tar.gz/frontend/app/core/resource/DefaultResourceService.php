<?php

namespace hitb\core\resource;

/**
 * Default implementation of {@link ResourceService}.
 */
class DefaultResourceService implements ResourceService {

	public function getResourceHandle($file) {

		if ($file == null || empty($file)) {
			throw new \Exception("File is required");
		}

		if (!file_exists($file)) {
			throw new \Exception("File " . $file . " not found");
		}

		$fp = fopen($file, "r");

		return $fp;
	}

}

