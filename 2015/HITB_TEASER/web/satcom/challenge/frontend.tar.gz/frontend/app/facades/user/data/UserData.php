<?php

namespace hitb\facades\user\data;

/**
 * DTO for a user
 *
 */
class UserData {

	private $uid;
	private $name;
	private $clearanceLevel;

	public function getUid() {
		return $this->uid;
	}

	public function setUid($uid) {
		$this->uid = $uid;
	}

	public function getName() {
		return $this->name;
	}

	public function setName($name) {
		$this->name = $name;
	}

	public function getClearanceLevel() {
		return $this->clearanceLevel;
	}

	public function setClearanceLevel($clearanceLevel) {
		$this->clearanceLevel = $clearanceLevel;
	}
}

