<?php

namespace hitb\core\activity;

/**
 * Interface for a service that loads activities.
 */
interface ActivityService {

	/**
	 * Fetches the latest activities
	 *
	 */
	function getLatestActivities();

}
