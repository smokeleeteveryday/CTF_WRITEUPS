<?php

namespace hitb\facades\transponder\converter;

use hitb\core\model\Transponder;

use hitb\facades\transponder\data\TransponderData;

use hitb\util\converter\AbstractConverter;

/**
 * Converter for transponders.
 */
class TransponderConverter extends AbstractConverter {

	private $locationService;

	/**
	 * Converts the given Transponder to a TransponderData object.
	 *
	 * @param $source
	 * @param $target
	 * @return
	 */
	public function convertExisting($source, $target) {

		$target->setId($source->getId());
		$target->setSic($source->getSic());
		$target->setLocation($this->getLocationService()->getLocationById($source->getLocation()));
		$target->setClearanceLevel($source->getClearanceLevel());
		$target->setActive($source->getActive() == 1);
		$target->setLinkSpeed($source->getLinkSpeed());
		$target->setLastStatus($source->getLastStatus());
		$target->setTotalPacketsRecv($source->getTotalPacketsRecv());
		$target->setDateAdded($source->getDateAdded());
		$target->setDateLastTransmission($source->getDateLastTransmission());
		$target->setDateLastStatus($source->getDateLastStatus());

		return $target;
	}

	public function createTarget() {
		return new TransponderData();
	}

	public function getLocationService() {
		return $this->locationService;
	}

	public function setLocationService($locationService) {
		$this->locationService = $locationService;
	}

}

