<?php

namespace hitb\core\activity;

use hitb\core\model\Activity;
use hitb\core\ModelNotFoundException;

/**
 * Default implementation of {@link ActivityService}.
 */
class DefaultActivityService implements ActivityService {

	public function getLatestActivities() {

		$activities = Activity::find(array(
			"order" => "id",
			"limit" => 20
		));

		return $activities;
	}

}
