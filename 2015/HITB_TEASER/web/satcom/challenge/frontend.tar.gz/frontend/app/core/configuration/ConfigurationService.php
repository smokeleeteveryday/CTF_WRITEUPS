<?php

namespace hitb\core\configuration;

/**
 * Interface for a service that provides configuration properties.
 */
interface ConfigurationService {

	/**
	 * Fetches a configuration value by key.
	 *
	 * @param $key the configuration key
	 * @throws ModelNotFoundException
	 * @return the configuration value
	 */
	function get($key);

}

