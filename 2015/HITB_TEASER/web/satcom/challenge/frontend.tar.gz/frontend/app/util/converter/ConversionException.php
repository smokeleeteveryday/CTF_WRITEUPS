<?php

namespace hitb\util\converter;

/**
 * Represents an exception that occurs during object conversion.
 */
class ConversionException extends \Exception {

	/**
	 * Constructor that makes message a required parameter.
	 *
 	 * @param $message
	 * @param $code
	 */
	public function __construct($message, $code = 0) {
		parent::__construct($message, $code);
	}

}

