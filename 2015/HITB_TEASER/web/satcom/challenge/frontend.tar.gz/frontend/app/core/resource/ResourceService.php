<?php

namespace hitb\core\resource;

/**
 * Interface for a service that loads a resource.
 */
interface ResourceService {

	/**
	 * Opens a file and returns the file pointer.
	 *
	 * @param $file the resource identifier
	 * @return fp
	 */
	function getResourceHandle($file);

}

