<?php

namespace hitb\facades\user\converter;

use hitb\facades\user\data\UserData;

use hitb\util\converter\AbstractConverter;

/**
 * Converter for users.
 */
class UserConverter extends AbstractConverter {

	/**
	 * Converts the given User to a UserData object
	 *
	 * @param $source
	 * @param $target
	 * @return
	 */
	public function convertExisting($source, $target) {

		$target->setUid($source->getUid());
		$target->setName($source->getName());
		$target->setClearanceLevel($source->getClearanceLevel());

		return $target;
	}

	public function createTarget() {
		return new UserData();
	}

}

