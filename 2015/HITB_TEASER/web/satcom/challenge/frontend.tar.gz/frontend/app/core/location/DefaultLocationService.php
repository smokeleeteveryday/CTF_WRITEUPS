<?php

namespace hitb\core\location;

/**
 * Default implementation of {@link LocationService}.
 */
class DefaultLocationService implements LocationService {

	public function getLocationById($locationId) {

		if ($locationId == "CTF") {
			return "Capture the Flag Event";
		}

		return $locationId;
	}

}

