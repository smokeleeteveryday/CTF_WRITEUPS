<?php

namespace hitb\core\security;

/**
 * Interface that provides an authentication mechanism.
 */
interface AuthenticationService {

	/**
	 * Verifies the given credentials.
	 *
	 * @param $uid the user id
	 * @param $pwd the password
	 * @throws InvalidCredentialsException
	 * @return user instance
	 */
	function verifyCredentials($uid, $pwd);

}
