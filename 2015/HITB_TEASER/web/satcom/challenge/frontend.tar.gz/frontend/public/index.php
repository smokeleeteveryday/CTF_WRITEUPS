<?php

try {

	// Load configuration
	$config = include "../app/config/config.php";

	// Register autoloader
	include "../app/config/loader.php";

	// Register services
	include "../app/config/services.php";

	// Handle the request
	$application = new \Phalcon\Mvc\Application($di);
	echo $application->handle()->getContent();

} catch (\Exception $e) {
	echo "An error occurred";
}

