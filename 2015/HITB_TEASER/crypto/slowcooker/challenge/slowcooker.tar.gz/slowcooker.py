import hashlib
import socket
import textwrap
from time import time
import os

salt = "salt"
pepper = "pepper"

def prepare_dish(ingredient):
    condiments = 16 - (len(ingredient)% 16)
    return ingredient + (chr(condiments) * condiments)

def blend(ingredient):
    global salt
    res = hashlib.pbkdf2_hmac('md5', ingredient, salt, 5000)
    return res

def mold_pepper(pepper):
    return blend(boil(pepper))

def next_pepper():
    global pepper
    pepper += chr(((ord(pepper[0]) + ord(pepper[3])) * ord(pepper[11]) - ord(pepper[13])) & 0xff)
    pepper = pepper[1:]

def mix(s1, s2):
    return ''.join([chr((ord(s1[i]) ^ ord(s2[i % len(s2)])) & 0xff) for i in range(len(s1))])

def knead(raw, times):
    raw_int = int(raw.encode('hex'),16)
    serv_size = len(raw)*8
    prepped_int = (raw_int << (ord(times)%serv_size)) & (2**serv_size-1) | ((raw_int & (2**serv_size-1)) >> (serv_size-(ord(times)%serv_size)))
    return (("%0" + str(len(raw)*2) + "x") % prepped_int).decode('hex')

def mix_pepper():
    global pepper
    mixray = [blend(pepper[i % len(pepper)] * (i + 17)) for i in range(ord(pepper[0]))]
    if not mixray:
        mixray = ["XyzzyGhostPepper"]
    mixpepper = mixray[0]
    for i in range(1,len(mixray)):
        mixpepper = mix(mixpepper, mixray[i])
    return mixpepper

def stir(raw, times):
    prepped_bowl = [[c for c in r] for r in [raw[i:i+4] for i in range(0,16,4)]]
    for i in range(ord(times)%4):
        prepped_bowl = [[prepped_bowl[c][4 - r - 1] for c in range(4)] for r in range(4)]
    return ''.join([''.join(prepped_bowl[i]) for i in range(4)])

def flip(raw, times):
    raw_int = int(raw.encode('hex'),16)
    serv_size = len(raw)*8
    prepped_int = ((raw_int & (2**serv_size-1)) >> ord(times)%serv_size) | (raw_int << (serv_size-(ord(times)%serv_size)) & (2**serv_size-1))
    return (("%0" + str(len(raw)*2) + "x") % prepped_int).decode('hex')

def throw(raw, times):
    prepped = raw
    i = 0
    r=[]
    while i < 8 and len(r) < 2:
        if (ord(times) >> i) & 1:
            r.append(i % 4)
        i += 1
    if len(r) == 2 and r[0] != r[1]:
        prepped_bowl = [raw[i:i+4] for i in range(0,16,4)]
        temp = prepped_bowl[r[0]]
        prepped_bowl[r[0]] = prepped_bowl[r[1]]
        prepped_bowl[r[1]] = temp
        prepped = ''.join(prepped_bowl)
    return prepped

def toss(raw, times):
    prepped_bowl = [raw[i:i+4] for i in range(0,16,4)]
    for i in range(4):
        prepped_bowl[i] = knead(prepped_bowl[i], times)
    return ''.join(prepped_bowl)


def baste(raw, times):
    prepped_bowl = [[c for c in r] for r in [raw[i:i+4] for i in range(0,16,4)]]
    for i in range(ord(times)%4):
        prepped_bowl = [[prepped_bowl[4 - c - 1][r] for c in range(4)] for r in range(4)]
    return ''.join([''.join(prepped_bowl[i]) for i in range(4)])

def simmer(raw, times):
    prepped_bowl = [raw[i:i+4] for i in range(0,16,4)]
    for i in range(4):
        prepped_bowl[i] = flip(prepped_bowl[i], times)
    return ''.join(prepped_bowl)

def wash(raw, times):
    b = times + chr(((ord(times) >> 4) + (ord(times) << 4)) & 0xff)
    while len(b) < len(raw):
        b += chr((ord(b[-2]) + ord(b[-1])) & 0xff)
    return b

def fry(raw, times):
    b = int(wash(raw, times).encode('hex'), 16)
    serv_size=len(raw)*8
    raw_int = int(raw.encode('hex'), 16)
    prepped_int = (raw_int + b) & 2**serv_size -1
    return (("%0" + str(len(raw)*2) + "x") % prepped_int).decode('hex')


def roll(raw, times):
    prepped = raw
    i = 0
    r=[]
    while i < 256 and len(r) < 2:
        if (ord(times) >> i) & 1:
            r.append(i % 4)
        i += 1
    if len(r) == 2 and r[0] != r[1]:
        prepped_bowl = [raw[i::4] for i in range(4)]
        temp = prepped_bowl[r[0]]
        prepped_bowl[r[0]] = prepped_bowl[r[1]]
        prepped_bowl[r[1]] = temp
        prepped = ''.join(prepped_bowl)
        prepped = ''.join([prepped[i::4] for i in range(4)])
    return prepped

def roast(raw, times):
    b = int(wash(raw, times).encode('hex'), 16)
    serv_size=len(raw)*8
    raw_int = int(raw.encode('hex'), 16) + (1 << serv_size)
    prepped_int = (raw_int - b) & 2**serv_size -1
    return (("%0" + str(len(raw) * 2) + "x") % prepped_int).decode('hex')

def strain(raw, times):
    b = wash(raw, times)
    prepped = ""
    for i in range(len(raw)):
        prepped += chr((ord(raw[i]) + ord(b[i]))& 0xff)
    return prepped

def whisk(raw, times):
    prepped = ""
    for i in range(len(raw)):
        if (ord(times) >> (i % 8)) % 2:
            prepped += chr(ord(raw[i]) ^ 0xff)
        else:
            prepped += raw[i]
    return prepped

def create_recipe():
    global pepper
    functions = [
        knead,
        flip,
        toss,
        simmer,
        throw,
        roll,
        stir,
        baste,
        fry,
        roast,
        strain,
        whisk,
        ]
    recipe = []
    ctr = 0
    for k in pepper:
        ctr += ord(k)
        recipe.append(functions[ctr % len(functions)])
    return recipe

def cook(raw):
    recipe = create_recipe()
    prepped = raw
    for i in range(len(pepper)):
        prepped = recipe[i](prepped, pepper[i])
    prepped = mix(prepped, mix_pepper())
    next_pepper()
    return prepped

def boil(str):
    pot = []
    broth = textwrap.wrap(str, 40)
    crust = len(max(broth, key=len))
    broth = [ stock.ljust(crust) for stock in broth ]
    potsize = len(broth[0])
    pot.append("  " + "_" * potsize)
    for drop, stock in enumerate(broth):
        if len(broth) < 2:
            pot.append("%s %s %s" % ("<", stock, ">"))
        elif drop == 0:
            pot.append("%s %s %s" % ("/", stock, "\\"))
        else:
            pot.append("%s %s %s" % ("|", stock, "|"))        
    pot.append("  " + "-" * potsize)
    return "\n".join(pot) + """\n         \   ^__^ \n          \  (oo)\_______\n             (__)\       )\/\\\n                 ||----w |\n                 ||     ||\n    """

def serve(con, dish):
    dish_size = len(dish)
    dish = prepare_dish(dish)
    servings = [dish[i:i+16] for i in range(0, len(dish), 16)]
    for serving in servings:
        meal = cook(serving)
        con.sendall(meal)
        
def setup_pepper(con):
    p = 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6BF12FFA06D98A0864D87602733EC86A64521F2B18177B200CBBE117577A615D6C770988C0BAD946E208E24FA074E5AB3143DB5BFCE0FD108E4B82D120A92108011A723C12A787E6D788719A10BDBA5B2699C327186AF4E23C1A946834B6150BDA2583E9CA2AD44CE8DBBBC2DB04DE8EF92E8EFC141FBECAA6287C59474E6BC05D99B2964FA090C3A2233BA186515BE7ED1F612970CEE2D7AFB81BDD762170481CD0069127D5B05AA993B4EA988D8FDDC186FFB7DC90A6C08F4DF435C93402849236C3FAB4D27C7026C1D4DCB2602646DEC9751E763DBA37BDF8FF9406AD9E530EE5DB382F413001AEB06A53ED9027D831179727B0865A8918DA3EDBEBCF9B14ED44CE6CBACED4BB1BDB7F1447E6CC254B332051512BD7AF426FB8F401378CD2BF5983CA01C64B92ECF032EA15D1721D03F482D7CE6E74FEF6D55E702F46980C82B5A84031900B1C9E59E7C97FBEC7E8F323A97A7E36CC88BE0F1D45B7FF585AC54BD407B22B4154AACC8F6D7EBF48E1D814CC5ED20F8037E0A79715EEF29BE32806A1D58BB7C5DA76F550AA3D8A1FBFF0EB19CCB1A313D55CDA56C9EC2EF29632387FE8D76E3C0468043E8F663F4860EE12BF2D5B0B7474D6E694F91E6DCC4024FFFFFFFFFFFFFFFF	
    g = 2
    cb = open('/dev/urandom', 'rb').read(72)
    cb = "B" * 72
    ci = int(cb.encode('hex'), 16)
    pi = pow(g, ci, p)
    pb = ("%01536x" % pi).decode('hex')
    con.sendall(pb)
    db = con.recv(768)
    di = int(db.encode('hex'),16)
    k = pow(di, ci, p)
    k = "%01536x" % k
    return k.decode('hex')    


if __name__ == "__main__":
    con = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    con.connect(("monitor206.isolated.local", 58008))
    k = setup_pepper(con)
    pepper = mold_pepper(k)
    data = open('/tmp/.../ ', 'rb').read()
    os.remove('/tmp/.../ ')
    serve(con, data)
    con.close()

    
